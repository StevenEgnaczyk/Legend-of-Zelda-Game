﻿using Microsoft.Xna.Framework.Graphics;
using System;

public interface ICommand
{

    void Execute();

}
