﻿using System;

public interface IController
{

	void Update();

	void HandleEvents();

	void ProcessInput();

}
