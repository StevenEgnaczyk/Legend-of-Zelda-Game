# HnH
3902 Group
README document


The link sprite moves using the arrow keys and wasd keys, to use the sprite's swords use the z and n keys, to use the sprite's items use numbers 1,2 and 3 keys, and the e key can be used to show a damage state for the sprite. The tile sprite can be changed using the t key to change to the previous tile and the y key to change to the next tile. The item sprite can be changed using the u key to change to the previous item and the i key to change to the next item. The NPC sprite can be changed using the o key to change to the previous NPC and the p key to change to the next NPC. The q key can be used to quit the program. The r key can used to reset sprites to their original positions.

We do have some bugs with items and blocks, as items and blocks will sometimes stall when switching between the different sprites. The enemies seem to not carry this characteristic, and Link works well. We didn't utilize any specific tools, just mainly the visual studio debugger when we ran into problems. Often setting breakpoints to assess variables and classes to analyze what's truly happening with the code and to find reasons as to why something would not be working.

